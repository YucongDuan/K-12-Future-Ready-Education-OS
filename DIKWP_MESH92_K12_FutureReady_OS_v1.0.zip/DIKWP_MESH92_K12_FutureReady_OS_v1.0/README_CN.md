# DIKWP Mesh92 中小学生未来就业韧性培养与课程重构系统

版本：1.0.0  
发布日期：2026-08-24  
作者：段玉聪 / Yucong Duan  
运行模式：`MESH92_CAUSAL_WORLD_MODEL_COEVOLUTION_REALITY_CONTACT_CLOSURE`  
许可证：Apache-2.0

## 1. 交付目标

本系统面向AI当前及未来就业冲击，在中国现有中小学课程结构内重构培养任务与评价方式。它不押注某个具体职业，也不承诺个体就业结果，而是提升学生的基础学力、AI与数据素养、真实问题解决、工程创造、沟通服务、伦理安全、健康韧性和多路径迁移能力。

系统完整覆盖：

- 1—12年级；
- 8种可变的代表性学生支持类型；
- 4种跨类型叠加支持条件；
- 96个“年级×支持类型”详细方案；
- 48个分年级真实项目；
- 4个竞争性就业世界模型；
- 学习护照、Mesh92试点台账、现实债务和治理边界审计。

## 2. 快速启动

直接双击 `index.html`，用现代浏览器打开。无需服务器、账号、模型API、数据库或网络。

可选CLI（只使用Python标准库）：

```bash
python tools/generate_plan.py --grade 7 --profile P4 --overlay O1 --alias 示例学生A --out outputs/demo.json
```

验证发行包：

```bash
python tools/validate_release.py
python tools/static_boundary_audit.py
python -m unittest discover -s tests -v
```

## 3. 重要边界

- 不作自动升学、分班、心理、纪律、能力或职业决定；
- 不做隐蔽画像、永久标签或排除性排名；
- 小学生不得独立使用开放式生成内容功能；
- AI输出不得直接成为学生评价结论；
- 不收集身份证、密码、人脸声纹、精确住址、健康诊断等敏感信息；
- 不伪造作业、实验、志愿、竞赛、申请或个人贡献；
- 类型只能用于当前支持配置，必须允许学生退出、调整和人工申诉；
- 预测没有现实结果就形成“现实债务”，需要补测、说明或退役。

## 4. 数据与目录

- `data/core_data.json`：完整版本化数据集；
- `data/grade_profile_matrix.csv`：96类方案电子表格；
- `data/project_library.json`：48个项目；
- `data/world_models.json`：4个竞争世界模型；
- `data/evidence_register.json`：证据台账；
- `src/k12_future_ready/engine.py`：规划引擎；
- `docs/`：架构、实施、治理、数据字典和试点协议；
- `release/`：验证结果与文件校验和。

## 5. 本地数据说明

网页端的学习护照和试点台账仅使用浏览器 `localStorage`。数据不会被本系统发送到网络，但使用公共电脑时应导出后清空。学校正式部署仍需完成本单位的数据保护、权限、留存和删除制度。

## 6. 引用与设计谱系

本项目继承段玉聪 DIKWP 开源生态中的证据台账、行动票、人工复核、学习/就业护照与静态边界审计模式，并按照 Mesh92 重构为：证据 → 多元世界模型 → 预测 → 授权可逆干预 → 现实结果 → 校准 → 模型修订/退役 → 记忆再巩固 → 因果交接。

相关项目：`https://github.com/YucongDuan/DIKWP-AI-CareerBridge-Studio-2026-V1`

## 7. 免责声明

本系统是教育规划、校本课程重构和试点研究工具，不是就业预测器、升学决策器或心理/能力诊断工具。学校实施必须遵守国家课程方案、未成年人保护、个人信息保护、生成式AI使用和地方教育管理要求。
