#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    "index.html", "assets/app.js", "assets/style.css", "data/core_data.json",
    "data/grade_profile_matrix.json", "data/grade_profile_matrix.csv",
    "README_CN.md", "README.md", "LICENSE", "NOTICE",
]


def main() -> int:
    errors = []
    for rel in REQUIRED:
        if not (ROOT / rel).is_file():
            errors.append(f"missing: {rel}")
    data = json.loads((ROOT / "data" / "core_data.json").read_text(encoding="utf-8"))
    if len(data.get("grades", [])) != 12:
        errors.append("grades must contain 12 records")
    if len(data.get("profiles", [])) != 8:
        errors.append("profiles must contain 8 records")
    if len(data.get("matrix", [])) != 96:
        errors.append("matrix must contain 96 plans")
    if len({p["plan_id"] for p in data.get("matrix", [])}) != 96:
        errors.append("plan_id must be unique")
    if any(len(g.get("projects", [])) != 4 for g in data.get("grades", [])):
        errors.append("each grade must contain four projects")
    if len(data.get("world_models", [])) < 2:
        errors.append("Mesh92 requires plural world models")
    with (ROOT / "data" / "grade_profile_matrix.csv").open(encoding="utf-8-sig") as handle:
        rows = list(csv.DictReader(handle))
    if len(rows) != 96:
        errors.append("CSV matrix must contain 96 rows")
    result = {
        "ok": not errors,
        "version": data.get("meta", {}).get("version"),
        "counts": {
            "grades": len(data.get("grades", [])),
            "profiles": len(data.get("profiles", [])),
            "plans": len(data.get("matrix", [])),
            "projects": sum(len(g.get("projects", [])) for g in data.get("grades", [])),
            "world_models": len(data.get("world_models", [])),
            "evidence_records": len(data.get("evidence_register", [])),
        },
        "errors": errors,
    }
    (ROOT / "release" / "VALIDATION.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
