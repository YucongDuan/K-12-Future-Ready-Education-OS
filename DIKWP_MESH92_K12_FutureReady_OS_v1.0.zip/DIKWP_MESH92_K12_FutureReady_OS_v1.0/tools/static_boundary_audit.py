#!/usr/bin/env python3
from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CHECKS = {
    "no_external_script": re.compile(r"<script[^>]+src=[\"']https?://", re.I),
    "no_external_css": re.compile(r"<link[^>]+href=[\"']https?://", re.I),
    "no_network_fetch": re.compile(r"\b(fetch|XMLHttpRequest|WebSocket)\s*\(", re.I),
    "no_analytics": re.compile(r"google-analytics|gtag\(|segment\.com|mixpanel|hotjar", re.I),
    "no_high_stakes_claim": re.compile(r"自动(决定|判定).{0,8}(升学|职业|分班|能力)", re.I),
}


def main() -> int:
    targets = [ROOT / "index.html", ROOT / "assets" / "app.js", ROOT / "assets" / "style.css"]
    findings = []
    for path in targets:
        text = path.read_text(encoding="utf-8")
        for name, pattern in CHECKS.items():
            if pattern.search(text):
                findings.append({"check": name, "file": str(path.relative_to(ROOT))})
    result = {"ok": not findings, "findings": findings, "checked": [str(p.relative_to(ROOT)) for p in targets]}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
