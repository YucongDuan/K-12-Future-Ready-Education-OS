#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from k12_future_ready import generate_plan, save_plan  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate a DIKWP Mesh92 K-12 future-ready education plan.")
    parser.add_argument("--grade", type=int, required=True, help="1-12")
    parser.add_argument("--profile", required=True, choices=[f"P{i}" for i in range(1, 9)])
    parser.add_argument("--overlay", action="append", default=[], choices=[f"O{i}" for i in range(1, 5)])
    parser.add_argument("--alias", default="匿名学生")
    parser.add_argument("--school-context", default="普通学校")
    parser.add_argument("--out", type=Path, default=ROOT / "outputs" / "generated_plan.json")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    plan = generate_plan(args.grade, args.profile, args.overlay, args.alias, args.school_context)
    save_plan(plan, args.out)
    print(json.dumps({"ok": True, "path": str(args.out), "plan_id": plan["plan"]["plan_id"]}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
