from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any, Dict, Iterable, List

PACKAGE_ROOT = Path(__file__).resolve().parents[2]
DATA_PATH = PACKAGE_ROOT / "data" / "core_data.json"


def load_data(path: Path | None = None) -> Dict[str, Any]:
    """Load the versioned curriculum and planning dataset."""
    target = path or DATA_PATH
    with target.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def _index(items: Iterable[Dict[str, Any]], key: str) -> Dict[str, Dict[str, Any]]:
    return {str(item[key]): item for item in items}


def generate_plan(
    grade: int,
    profile_id: str,
    overlays: List[str] | None = None,
    student_alias: str = "匿名学生",
    school_context: str = "普通学校",
    data: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    """Generate an auditable plan. It never predicts a student's fixed ability or job."""
    data = data or load_data()
    if grade not in range(1, 13):
        raise ValueError("grade must be an integer from 1 to 12")
    profile_ids = {p["id"] for p in data["profiles"]}
    if profile_id not in profile_ids:
        raise ValueError(f"unknown profile_id: {profile_id}")
    overlay_ids = {o["id"] for o in data["overlays"]}
    selected_overlays = overlays or []
    unknown = set(selected_overlays) - overlay_ids
    if unknown:
        raise ValueError(f"unknown overlay ids: {sorted(unknown)}")

    matrix_idx = {row["plan_id"]: row for row in data["matrix"]}
    base = copy.deepcopy(matrix_idx[f"G{grade:02d}-{profile_id}"])
    overlay_idx = _index(data["overlays"], "id")
    grade_idx = _index(data["grades"], "grade")
    profile_idx = _index(data["profiles"], "id")
    chosen_overlay_records = [copy.deepcopy(overlay_idx[o]) for o in selected_overlays]

    plan = {
        "meta": {
            "system": data["meta"]["name_en"],
            "version": data["meta"]["version"],
            "mesh_mode": data["meta"]["mode"],
            "student_alias": student_alias,
            "school_context": school_context,
            "high_stakes_decision": False,
            "human_review_required": True,
        },
        "identity_guard": {
            "statement": "类型仅用于当前支持配置，可随证据调整，不代表固定能力、人格或职业命运。",
            "profile": profile_idx[profile_id],
            "overlays": chosen_overlay_records,
        },
        "plan": base,
        "grade_context": grade_idx[str(grade)],
        "plural_world_models": copy.deepcopy(data["world_models"]),
        "noncompensatory_gates": copy.deepcopy(data["noncompensatory_gates"]),
        "review_ticket": {
            "teacher_review": None,
            "student_review": None,
            "guardian_review": None,
            "authorized": False,
            "pilot_start": None,
            "pilot_end": None,
        },
        "outcome_ledger": [],
        "calibration": {
            "prediction_count": len(base["mesh92_predictions"]),
            "outcome_count": 0,
            "reality_debt": len(base["mesh92_predictions"]),
            "model_revision": None,
        },
    }
    return plan


def record_outcome(plan: Dict[str, Any], metric: str, observed: str, evidence_ref: str) -> Dict[str, Any]:
    """Append an outcome and reduce reality debt. This is intentionally human-entered."""
    if not metric.strip() or not observed.strip() or not evidence_ref.strip():
        raise ValueError("metric, observed and evidence_ref are required")
    plan = copy.deepcopy(plan)
    plan.setdefault("outcome_ledger", []).append({
        "metric": metric.strip(),
        "observed": observed.strip(),
        "evidence_ref": evidence_ref.strip(),
        "human_verified": True,
    })
    cal = plan.setdefault("calibration", {})
    cal["outcome_count"] = len(plan["outcome_ledger"])
    cal["reality_debt"] = max(0, int(cal.get("prediction_count", 0)) - cal["outcome_count"])
    return plan


def save_plan(plan: Dict[str, Any], path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")
    return path
