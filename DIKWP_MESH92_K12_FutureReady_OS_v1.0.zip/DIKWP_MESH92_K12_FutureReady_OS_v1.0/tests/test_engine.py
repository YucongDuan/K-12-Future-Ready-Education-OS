from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from k12_future_ready import generate_plan, load_data, record_outcome  # noqa: E402


class EngineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data = load_data()

    def test_dataset_counts(self):
        self.assertEqual(len(self.data["grades"]), 12)
        self.assertEqual(len(self.data["profiles"]), 8)
        self.assertEqual(len(self.data["matrix"]), 96)
        self.assertEqual(sum(len(g["projects"]) for g in self.data["grades"]), 48)

    def test_all_routes_generate(self):
        for grade in range(1, 13):
            for profile in [f"P{i}" for i in range(1, 9)]:
                plan = generate_plan(grade, profile)
                self.assertEqual(plan["plan"]["plan_id"], f"G{grade:02d}-{profile}")
                self.assertTrue(plan["meta"]["human_review_required"])
                self.assertFalse(plan["meta"]["high_stakes_decision"])

    def test_overlay_and_outcome(self):
        plan = generate_plan(7, "P4", ["O1", "O2"])
        self.assertEqual(len(plan["identity_guard"]["overlays"]), 2)
        before = plan["calibration"]["reality_debt"]
        plan2 = record_outcome(plan, "作品证据", "完成原型并复测", "作品夹/07")
        self.assertEqual(plan2["calibration"]["reality_debt"], before - 1)

    def test_invalid_inputs(self):
        with self.assertRaises(ValueError):
            generate_plan(13, "P1")
        with self.assertRaises(ValueError):
            generate_plan(1, "P9")
        with self.assertRaises(ValueError):
            generate_plan(1, "P1", ["O9"])


if __name__ == "__main__":
    unittest.main()
