# 数据字典

## `grades`

每个年级记录：`grade`、`stage`、`theme`、`development`、`annual_goal`、`weekly`、`ai_boundary`、`subject_actions`、`projects`。

## `profiles`

8个可逆支持类型。`id`为P1—P8。类型不代表诊断、固定人格或能力上限。

## `overlays`

O1—O4为县域/低资源、无障碍、语言迁移、资源丰富/拔尖扩展等叠加条件，可与任一类型组合。

## `matrix`

96条计划记录，主键为`G{年级两位数}-{类型ID}`，如`G07-P4`。

## `world_models`

每个模型包含摘要、可观察信号、反证条件、教育响应和选择权资产。模型不含伪精确概率。

## `mesh92_predictions`

每条计划默认包含基础任务、作品证据和未来选择保留度三类事前预测。正式试点应将其改写为本校可测指标。
