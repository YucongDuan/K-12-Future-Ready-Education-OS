(() => {
  "use strict";
  const D = window.K12_DATA;
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s ?? "").replace(/[&<>'"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"}[c]));
  const save = (key, value) => localStorage.setItem(key, JSON.stringify(value));
  const load = (key, fallback=[]) => { try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; } };
  const download = (name, obj) => {
    const blob = new Blob([JSON.stringify(obj, null, 2)], {type:"application/json;charset=utf-8"});
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name; a.click(); URL.revokeObjectURL(a.href);
  };

  function showSection(id) {
    document.querySelectorAll(".panel").forEach(p => p.classList.toggle("active", p.id === id));
    document.querySelectorAll(".tab").forEach(t => t.classList.toggle("active", t.dataset.section === id));
    window.scrollTo({top: document.querySelector(".tabs").offsetTop, behavior:"smooth"});
  }
  document.querySelectorAll("[data-section]").forEach(b => b.addEventListener("click", () => showSection(b.dataset.section)));
  document.querySelectorAll("[data-nav]").forEach(b => b.addEventListener("click", () => showSection(b.dataset.nav)));

  $("versionBadge").textContent = `v${D.meta.version} · ${D.meta.mode}`;
  $("metrics").innerHTML = [
    [12,"覆盖年级"],[8,"代表性支持类型"],[96,"年级×类型方案"],[48,"真实项目"]
  ].map(([n,t]) => `<div class="metric"><b>${n}</b><span>${t}</span></div>`).join("");
  $("capabilityGrid").innerHTML = D.capabilities.map((c,i) => `<div class="capability-pill">${i+1}. ${esc(c)}</div>`).join("");

  const gradeOptions = (all=false) => `${all?'<option value="all">全部年级</option>':''}${D.grades.map(g=>`<option value="${g.grade}">${g.grade}年级 · ${esc(g.theme)}</option>`).join("")}`;
  const profileOptions = (all=false) => `${all?'<option value="all">全部类型</option>':''}${D.profiles.map(p=>`<option value="${p.id}">${p.id} · ${esc(p.name)}</option>`).join("")}`;
  $("gradeSelect").innerHTML = gradeOptions(); $("profileSelect").innerHTML = profileOptions();
  $("matrixGrade").innerHTML = gradeOptions(true); $("matrixProfile").innerHTML = profileOptions(true);
  $("projectGrade").innerHTML = gradeOptions(true); $("passportGrade").innerHTML = gradeOptions();
  $("overlayChecks").innerHTML = D.overlays.map(o=>`<label><input type="checkbox" value="${o.id}"><span><b>${esc(o.name)}</b><br><small>${esc(o.actions[0])}</small></span></label>`).join("");

  const matrixIndex = Object.fromEntries(D.matrix.map(m => [m.plan_id, m]));
  const gradeIndex = Object.fromEntries(D.grades.map(g => [g.grade, g]));
  const profileIndex = Object.fromEntries(D.profiles.map(p => [p.id, p]));
  const overlayIndex = Object.fromEntries(D.overlays.map(o => [o.id, o]));

  function planHTML(plan, overlays, alias, context) {
    const g = gradeIndex[plan.grade], p = profileIndex[plan.profile_id];
    const overlayActions = overlays.flatMap(id => overlayIndex[id]?.actions || []);
    return `<article class="card">
      <div class="plan-title"><div><span class="tag safe">${esc(plan.plan_id)}</span><h3>${esc(alias)}｜${plan.grade}年级｜${esc(p.name)}</h3><p>${esc(g.theme)} · ${esc(g.development)}</p></div><button class="ghost small" onclick="window.print()">打印/存PDF</button></div>
      <div class="chips">${plan.priority_capabilities.map(c=>`<span class="tag">${esc(c)}</span>`).join("")}<span class="tag warn">${esc(plan.learning_ratio)}</span></div>
      <div class="callout"><b>年度目标：</b>${esc(plan.annual_goal)}<br><b>周结构：</b>${esc(plan.weekly_structure)}${context?`<br><b>校情：</b>${esc(context)}`:""}</div>
      <div class="plan-section"><h4>现有学科内调整</h4><table class="subject-table"><thead><tr><th>学科/活动</th><th>调整任务</th><th>优先级</th></tr></thead><tbody>${plan.subject_recommendations.map(x=>`<tr><td>${esc(x.subject)}</td><td>${esc(x.action)}</td><td>${esc(x.priority)}</td></tr>`).join("")}</tbody></table></div>
      <div class="plan-section"><h4>锚点项目｜${esc(plan.anchor_project.name)}</h4><p>${esc(plan.anchor_project.brief)}</p><p><b>必须留下的证据：</b>${esc(plan.anchor_project.evidence)}</p></div>
      <div class="grid two plan-section">
        <div><h4>类型化支架</h4><ul class="compact-list">${plan.profile_adjustments.map(x=>`<li>${esc(x)}</li>`).join("")}</ul></div>
        <div><h4>作品集最低证据</h4><ul class="compact-list">${plan.portfolio_evidence.map(x=>`<li>${esc(x)}</li>`).join("")}</ul></div>
      </div>
      ${overlayActions.length?`<div class="plan-section"><h4>叠加支持</h4><ul class="compact-list">${overlayActions.map(x=>`<li>${esc(x)}</li>`).join("")}</ul></div>`:""}
      <div class="grid two plan-section"><div class="callout green"><b>教师：</b>${esc(plan.teacher_focus)}</div><div class="callout green"><b>家庭：</b>${esc(plan.family_focus)}</div></div>
      <div class="plan-section callout amber"><b>AI使用边界：</b>${esc(plan.ai_boundary)}</div>
      <div class="plan-section"><h4>Mesh92事前预测</h4><ul class="compact-list">${plan.mesh92_predictions.map(x=>`<li><b>${esc(x.metric)}：</b>${esc(x.prediction)}（${esc(x.deadline)}）</li>`).join("")}</ul><p class="micro">未在截止点补录现实结果的预测形成现实债务，必须解释、补测或退役。</p></div>
      <div class="plan-section"><h4>停止条件</h4><ul class="compact-list">${plan.stop_conditions.map(x=>`<li>${esc(x)}</li>`).join("")}</ul></div>
      <div class="plan-section"><h4>关联职业族（只用于探索，不作锁定）</h4><div class="chips">${plan.career_families.map(x=>`<span class="tag">${esc(x)}</span>`).join("")}</div><p>${esc(plan.review_cycle)}</p></div>
    </article>`;
  }

  function renderPlan() {
    const grade = Number($("gradeSelect").value), profile = $("profileSelect").value;
    const overlays = [...$("overlayChecks").querySelectorAll("input:checked")].map(x=>x.value);
    const alias = $("studentAlias").value.trim() || "匿名学生";
    const context = $("schoolContext").value.trim();
    const plan = matrixIndex[`G${String(grade).padStart(2,"0")}-${profile}`];
    $("planOutput").innerHTML = planHTML(plan, overlays, alias, context);
  }
  $("plannerForm").addEventListener("submit", e => { e.preventDefault(); renderPlan(); });
  $("resetPlanner").addEventListener("click", () => { $("plannerForm").reset(); $("studentAlias").value="匿名学生"; $("planOutput").innerHTML='<div class="empty">选择年级和支持类型，生成可由学校、教师、学生与家庭共同审阅的方案。</div>'; });
  $("planOutput").innerHTML='<div class="empty">选择年级和支持类型，生成可由学校、教师、学生与家庭共同审阅的方案。</div>';

  function renderMatrix() {
    const gv=$("matrixGrade").value, pv=$("matrixProfile").value;
    const rows=D.matrix.filter(x=>(gv==="all"||String(x.grade)===gv)&&(pv==="all"||x.profile_id===pv));
    $("matrixCards").innerHTML=rows.map(x=>`<article class="matrix-card"><span class="tag">${x.plan_id}</span><h3>${x.grade}年级 · ${esc(x.profile_name)}</h3><p><b>${esc(x.theme)}</b></p><p>${esc(x.annual_goal)}</p><p><b>项目：</b>${esc(x.anchor_project.name)}</p><details><summary>展开具体支持</summary><p><b>周结构：</b>${esc(x.weekly_structure)}</p><p><b>学习配比：</b>${esc(x.learning_ratio)}</p><ul>${x.profile_adjustments.map(a=>`<li>${esc(a)}</li>`).join("")}</ul><p><b>AI边界：</b>${esc(x.ai_boundary)}</p></details></article>`).join("") || '<div class="empty">没有匹配记录</div>';
  }
  $("matrixGrade").addEventListener("change",renderMatrix); $("matrixProfile").addEventListener("change",renderMatrix); renderMatrix();

  function renderProjects() {
    const gv=$("projectGrade").value;
    const gs=D.grades.filter(g=>gv==="all"||String(g.grade)===gv);
    $("projectCards").innerHTML=gs.flatMap(g=>g.projects.map(p=>`<article class="card project-card"><span class="project-grade">G${g.grade} · ${esc(g.stage)}</span><h3>${esc(p[0])}</h3><p>${esc(p[1])}</p><p class="evidence"><b>证据：</b>${esc(p[2])}</p></article>`)).join("");
  }
  $("projectGrade").addEventListener("change",renderProjects); renderProjects();

  $("worldCards").innerHTML=D.world_models.map(m=>`<article class="card world-card"><span class="model-id">${m.id}</span><h3>${esc(m.name)}</h3><p>${esc(m.summary)}</p><h4>可观察信号</h4><ul>${m.signals.map(x=>`<li>${esc(x)}</li>`).join("")}</ul><h4>反证/退役条件</h4><ul>${m.falsifiers.map(x=>`<li>${esc(x)}</li>`).join("")}</ul><h4>教育响应</h4><p>${esc(m.education_response)}</p><div class="chips">${m.option_value.map(x=>`<span class="tag">${esc(x)}</span>`).join("")}</div></article>`).join("");
  $("gateList").innerHTML=D.noncompensatory_gates.map((g,i)=>`<div class="gate"><b>GATE ${i+1}</b><br>${esc(g)}</div>`).join("");

  let passport=load("mesh92_k12_passport",[]);
  function renderPassport(){ $("passportList").innerHTML=passport.length?passport.map((x,i)=>`<div class="entry"><div class="card-head"><h4>${esc(x.title)}</h4><span class="tag">${x.grade}年级</span></div><p class="meta">${esc(x.created)}</p><p><b>问题：</b>${esc(x.problem)}</p><p><b>贡献：</b>${esc(x.contribution)}</p><p><b>证据：</b>${esc(x.evidence)}</p><p><b>AI/工具：</b>${esc(x.ai||"未使用/未填写")}</p><p><b>修改：</b>${esc(x.revision||"待补录")}</p></div>`).join(""):'<p class="micro">尚无记录。</p>'; }
  $("passportForm").addEventListener("submit",e=>{e.preventDefault();passport.unshift({grade:Number($("passportGrade").value),title:$("artifactTitle").value.trim(),problem:$("artifactProblem").value.trim(),contribution:$("artifactContribution").value.trim(),evidence:$("artifactEvidence").value.trim(),ai:$("artifactAI").value.trim(),revision:$("artifactRevision").value.trim(),created:new Date().toLocaleString()});save("mesh92_k12_passport",passport);e.target.reset();renderPassport();});
  $("exportPassport").addEventListener("click",()=>download("mesh92_learning_passport.json",passport));
  $("clearPassport").addEventListener("click",()=>{if(confirm("确认清空本浏览器中的学习护照记录？")){passport=[];save("mesh92_k12_passport",passport);renderPassport();}}); renderPassport();

  let pilots=load("mesh92_k12_pilots",[]);
  function renderPilots(){const debt=pilots.filter(x=>!x.outcome).length;$("debtBadge").textContent=`现实债务 ${debt}`;$("debtBadge").className=`badge ${debt?"debt":"cleared"}`;$("pilotList").innerHTML=pilots.length?pilots.map(x=>`<div class="entry"><div class="card-head"><h4>${esc(x.name)}</h4><span class="tag ${x.outcome?'safe':'warn'}">${x.outcome?'已有结果':'待补结果'}</span></div><p class="meta">${esc(x.created)}</p><p><b>证据：</b>${esc(x.evidence)}</p><p><b>模型：</b>${esc(x.models)}</p><p><b>预测：</b>${esc(x.prediction)}</p><p><b>干预：</b>${esc(x.intervention)}</p><p><b>停止：</b>${esc(x.stop)}</p><p><b>结果：</b>${esc(x.outcome||"尚未记录——形成现实债务")}</p></div>`).join(""):'<p class="micro">尚无试点记录。</p>';}
  $("pilotForm").addEventListener("submit",e=>{e.preventDefault();const models=$("pilotModels").value.split(/[；;]/).map(x=>x.trim()).filter(Boolean);if(models.length<2){alert("Mesh92要求至少登记两个非同构模型。请用分号分隔。");return;}pilots.unshift({name:$("pilotName").value.trim(),evidence:$("pilotEvidence").value.trim(),models:models.join("；"),prediction:$("pilotPrediction").value.trim(),intervention:$("pilotIntervention").value.trim(),stop:$("pilotStop").value.trim(),outcome:$("pilotOutcome").value.trim(),created:new Date().toLocaleString()});save("mesh92_k12_pilots",pilots);e.target.reset();renderPilots();});
  $("exportPilots").addEventListener("click",()=>download("mesh92_pilot_ledger.json",pilots));
  $("clearPilots").addEventListener("click",()=>{if(confirm("确认清空本浏览器中的试点记录？")){pilots=[];save("mesh92_k12_pilots",pilots);renderPilots();}}); renderPilots();
})();
